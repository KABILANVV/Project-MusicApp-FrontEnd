import React from 'react'
import { Link } from 'react-router-dom'
// import "./side.css"

function Sidebar() {
  return (
    <div className='sideBar'>
    <Link to='/'>
    <button className='btn'>Home</button>
    <br/>
    </Link>
    <Link to='/'>
    <button className='Sideitem'>About</button>
    <br/>
    </Link>
    <Link to='/'>
    <button className='Sideitem'>Contact us</button>
    <br/>
    </Link>
    <Link to='/'>
    <button className='Sideitem'>Create Account</button>
    <br/>
    </Link>
    <Link to='/'>
    <button className='Sideitem'>Transaction</button>
    <br/>
    </Link>
    <Link to='/'>
    <button className='Sideitem'>Mobile Deposit</button>
    <br/>
    </Link>
    </div>
  )
}

export default Sidebar