import React, { Component } from 'react'
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import './home.css'

import { Row ,Col} from 'react-bootstrap';

function SearchBar() {
  return (
      <Row >
        <Col sm={28}>
          <Form  id="searchbar" className="d-flex flex-row">
            <Form.Control
              type="search"
              id="search"
              placeholder="Search"
              className="me-2"
              aria-label="Search"
            />
            <button id="searchbar" className="btn btn-light" variant="outline-primary">
              Search
            </button>
          </Form>
        </Col>
      </Row>
  )
}

function NavbarTop() {
  return (
    <>
        <Navbar.Brand href="#">Music </Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        
      {/* <Navbar.Collapse id="navbarScroll"> */}
          <Nav
            className="me-auto my-2 my-lg-0"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
          
          </Nav>
      {/* </Navbar.Collapse> */}
    </>
  )
}
function Avatar() {
  return (
    <>
        <p
        class="nav-link dropdown-toggle hidden-arrow d-flex align-items-center"
        href="#"
        id="navbarDropdownMenuLink"
        role="button"
        data-mdb-toggle="dropdown"
        aria-expanded="false"
        >
       <img
            src="https://mdbootstrap.com/img/Photos/Avatars/img (31).jpg"
            class="rounded-circle"
            height="50"
            alt=""
            loading="lazy"
            />
            </p>
            </>
  )
}

export class Home extends Component {
  render() {
    return (
    <>
      <Navbar expand="lg" className="bg-body-tertiary">
        <Container fluid>
          <Navbar.Collapse>
            <NavbarTop/>
            <SearchBar/>
            <Avatar/>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </>
    )
  }
}

export default Home;
