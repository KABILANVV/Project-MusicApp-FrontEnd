import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Login from './User/login'
import Forms from './User/form'
import Home from './Home/Home'

function Routing() {
  return (
    <Routes>
        <Route exact path="" element={<Login/>}></Route>
        <Route exact path="home" element={<Home/>}></Route>
        <Route exact path="signup" element={<Forms/>}></Route>
    </Routes>
  )
}

export default Routing